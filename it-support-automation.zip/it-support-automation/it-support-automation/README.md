# IT Support Automation Script

A simple Python tool that automates ticket logging and resolution tracking for internal IT teams.

## Features
- Log new support tickets to a CSV file
- Mark tickets as resolved
- Timestamp and user-based tracking

## How to Use
1. Run `ticket_system.py`
2. Choose from menu options:
   - Create a new ticket
   - Resolve an existing one
3. Tickets are saved in `tickets.csv`

## Technologies
- Python 3.x
- Standard libraries: `csv`, `datetime`

## Future Improvements
- GUI interface with Tkinter or web-based Flask version
- Email notifications on ticket creation

## Author
[Yusuf Bukamal](https://github.com/Yousif-Abdulla)