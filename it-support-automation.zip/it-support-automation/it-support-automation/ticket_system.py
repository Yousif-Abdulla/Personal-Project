import csv
from datetime import datetime
import os

TICKET_FILE = "tickets.csv"

def get_next_ticket_number():
    if not os.path.exists(TICKET_FILE):
        return 1
    with open(TICKET_FILE, newline='') as file:
        reader = csv.reader(file)
        numbers = [int(row[0]) for row in reader if row]
        return max(numbers, default=0) + 1

def create_ticket():
    issue = input("Enter issue description: ")
    user = input("Enter user name: ")
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ticket_number = get_next_ticket_number()
    with open(TICKET_FILE, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([ticket_number, timestamp, user, issue, "Open"])
    print(f"Ticket created successfully. Ticket ID: {ticket_number}")

def resolve_ticket():
    ticket_id = input("Enter ticket ID to mark as resolved: ")
    updated = []
    found = False
    if not os.path.exists(TICKET_FILE):
        print("No tickets found.")
        return
    with open(TICKET_FILE, newline='') as file:
        reader = csv.reader(file)
        for row in reader:
            if row and row[0] == ticket_id and row[-1] == "Open":
                row[-1] = "Resolved"
                found = True
            updated.append(row)
    if not found:
        print("Invalid ticket ID or ticket already resolved.")
        return
    with open(TICKET_FILE, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(updated)
    print("Ticket updated.")

def main():
    while True:
        print("\n1. Create Ticket\n2. Resolve Ticket\n3. Exit")
        choice = input("Choose an option: ")
        if choice == "1":
            create_ticket()
        elif choice == "2":
            resolve_ticket()
        else:
            break

if __name__ == "__main__":
    main()