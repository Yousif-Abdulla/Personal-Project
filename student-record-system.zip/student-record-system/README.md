# Student Record System

A simple console-based Java application to manage student records using MySQL.

## Features
- Add students with name and email
- View all students
- Uses JDBC to connect to MySQL

## Technologies
- Java SE
- MySQL
- JDBC

## Database Schema
See `database.sql` to set up the `studentdb` database and `students` table.

## How to Run
1. Create the database using `database.sql`
2. Edit DB credentials in `StudentManager.java`
3. Compile and run the application:
   ```bash
   javac Student.java StudentManager.java
   java StudentManager
   ```

## Author
[Yusuf Bukamal](https://github.com/wine27)