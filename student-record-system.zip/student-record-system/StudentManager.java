import java.sql.*;
import java.util.Scanner;

public class StudentManager {
    static final String DB_URL = "jdbc:mysql://localhost/studentdb";
    static final String USER = "root";
    static final String PASS = "";

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Scanner sc = new Scanner(System.in)) {


            while (true) {
                System.out.println("\n1. Add Student\n2. View Students\n3. Exit");
                int choice = sc.nextInt();
                sc.nextLine();


                if (choice == 1) {
                    System.out.print("Name: ");
                    String name = sc.nextLine();
                    System.out.print("Email: ");
                    String email = sc.nextLine();


                    // Input validation
                    if (name.isEmpty() || email.isEmpty()) {
                        System.out.println("Name and email cannot be empty.");
                        continue;
                    }


                    try (PreparedStatement ps = conn.prepareStatement("INSERT INTO students (name, email) VALUES (?, ?)")) {
                        ps.setString(1, name);
                        ps.setString(2, email);
                        ps.executeUpdate();
                        System.out.println("Student added.");
                    } catch (SQLIntegrityConstraintViolationException e) {
                        System.out.println("Error: Email already exists.");
                    }

                } else if (choice == 2) {
                    try (Statement stmt = conn.createStatement();
                         ResultSet rs = stmt.executeQuery("SELECT * FROM students")) {
                        while (rs.next()) {
                            System.out.println(rs.getInt("id") + ": " + rs.getString("name") + " - " + rs.getString("email"));
                        }

                    }
                } else {
                    break;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}