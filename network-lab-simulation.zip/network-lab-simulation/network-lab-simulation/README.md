# Network Configuration Lab (Cisco Packet Tracer)

This project simulates a simple two-router network topology for training and demonstration purposes.

## Topology
- 2 Routers (R1, R2)
- 2 Switches
- 4 PCs (2 per switch)

## Configuration
- R1: LAN 192.168.1.0/24, WAN 10.0.0.1/30
- R2: LAN 192.168.2.0/24, WAN 10.0.0.2/30
- Static routing setup

## Tools
- Cisco Packet Tracer (save file: `Topology.pkt`)

## Commands
Refer to `network_setup.txt` for all router and interface configuration commands.

## Author
[Yusuf Bukamal](https://github.com/Yousif-Abdulla)